// C++ definition

#include "QCDNUM/QCDNUM.h"
//#include "QCDNUM/CHARACTER.h"
#include "QCDNUM/QCDNUMfw.h"

#include <sstream>
#include <cstring>
#include <string>
#include <iostream>
using namespace std;

#define STR_EXPAND(top) #top
#define STR(tok) STR_EXPAND(tok)

namespace QCDNUM {

  /*
    ==========================================
    Routines in the QCDNUM toolbox
    (corresponding to Table 4 of the write-up)
    ==========================================
  */

  /*--------------------------------------------------------------------
    Workspace
  --------------------------------------------------------------------*/

  // Create tables
  void maketab(double *w, int nw, int *itypes, int np, int neww, int &iset, int &nwu)
  {
    fmaketab(w,&nw,itypes,&np,&neww,&iset,&nwu);
  }

  // Store user information
  void setparw(double *w, int iset, double *upars, int n)
  {
    fsetparw(w,&iset,upars,&n);
  }

  // Read user information
  void getparw(double *w, int iset, double *upars, int n)
  {
    fgetparw(w,&iset,upars,&n);
  }

  // Dump to disk
  void dumptab(double *w, int iset, int lun, string fname, string key)
  {
    int l1 = fname.size();
    char *cfname = new char[l1];
    strcpy(cfname,fname.c_str());
    int l2 = key.size();
    char * ckey = new char[l2];
    strcpy(ckey,key.c_str());
    fdumptabcpp(w,&iset,&lun,cfname,&l1,ckey,&l2);
  }

  // Read from disk
  void readtab(double *w, int nw, int lun, string fname, string key, int neww, int &iset, int &nwu, int &ierr)
  {
    int l1 = fname.size();
    char *cfname = new char[l1];
    strcpy(cfname,fname.c_str());
    int l2 = key.size();
    char *ckey = new char[l2];
    strcpy(ckey,key.c_str());
    freadtabcpp(w,&nw,&lun,cfname,&l1,ckey,&l2,&neww,&iset,&nwu,&ierr);
  }

  /*--------------------------------------------------------------------
    Identifiers
  --------------------------------------------------------------------*/

  // Internal weight table
  int idspfun(string pij, int iord, int iset)
  {
    int ls = pij.size();
    char *cpij = new char[ls];
    strcpy(cpij,pij.c_str());
    return fidspfuncpp(cpij,&ls,&iord,&iset);
  }

  // Internal PDF table
  int ipdftab(int iset, int id)
  {
    return fipdftab(&iset,&id);
  }

  /*--------------------------------------------------------------------
    Weights
  --------------------------------------------------------------------*/

  // Regular piece A(x)
  void makewta(double *w, int id, double (*afun)(double*,double*,int*), double (*achi)(double*))
  {
    fmakewta(w,&id,afun,achi);
  }

  // Singular piece [B(x)]_+
  void makewtb(double *w, int id, double (*bfun)(double*,double*,int*), double (*achi)(double*), int nodelta)
  {
    fmakewtb(w,&id,bfun,achi,&nodelta);
  }

  // Product R(x)[S(x)]_+
  void makewrs(double *w, int id, double (*rfun)(double*,double*,int*), double (*sfun)(double*,double*,int*), double (*achi)(double*), int nodelta)
  {
    fmakewrs(w,&id,rfun,sfun,achi,&nodelta);
  }

  // Delta-function D(x)delta(1-x)
  void makewtd(double *w, int id, double (*dfun)(double*,double*,int*), double (*achi)(double*))
  {
    fmakewtd(w,&id,dfun,achi);
  } 

  // Weights for x[f_a \otime f_b]
  void makewtx(double *w, int id)
  {
    fmakewtx(w,&id);
  }

  /*--------------------------------------------------------------------
    Combined weights
  --------------------------------------------------------------------*/

  // Scale weight table
  void scalewt(double *w, double c, int id)
  {
    fscalewt(w,&c,&id);
  }

  // Copy weight table
  void copywgt(double *w, int id1, int id2, int iadd)
  {
    fcopywgt(w,&id1,&id2,&iadd);
  }

  // Convolution of weights
  void wcrossw(double *w, int ida, int idb, int idc, int iadd)
  {
    fwcrossw(w,&ida,&idb,&idc,&iadd);
  }

  // Multiply by f(mu2,nf)
  void wtimesf(double *w, double (*fun)(int*,int*), int id1, int id2, int iadd)
  {
    fwtimesf(w,fun,&id1,&id2,&iadd);
  }

  /*--------------------------------------------------------------------
    Evolution
  --------------------------------------------------------------------*/

  // Fill table of coefficients 
  void evfilla(double *w, int id, double (*func)(int*,int*,int*))
  {
    fevfilla(w,&id,func);
  }

  // Get coefficients
  double evgetaa(double *w, int id, int iq, int &nf, int &ithresh)
  {
    return fevgetaa(w,&id,&iq,&nf,&ithresh);
  }

  // Coupled evolution
  void evdglap(double *w, int ***idw, int ***ida, int *idf, double **start, int m, int n, int *iqlim, int &nf, double &epsi)
  {
    fevdglap(w,idw,ida,idf,start,&m,&n,iqlim,&nf,&epsi);
  }

  /*--------------------------------------------------------------------
    Access to pdfs
  --------------------------------------------------------------------*/

  //  PDF at a grid point
  double evpdfij(double *w, int id, int ix, int iq, int ichk)
  {
    return fevpdfij(w,&id,&ix,&iq,&ichk);
  }

  // List of interpolated PDFs
  void evplist(double *w, int id, double *x, double *qmu2, double *pdf, int n, int ichk)
  {
    fevplist(w,&id,x,qmu2,pdf,&n,&ichk);
  }

  // Table of interpolated PDFs
  void evtable(double *w, int id, double *x, int nx, double *q, int nq, double **table, int ichk)
  {
    fevtable(w,&id,x,&nx,q,&nq,table,&ichk);
  }

  // Copy to internal memory
  void evpcopy(double *w, int id, double **def, int n, int iset)
  {
    fevpcopy(w,&id,def,&n,&iset);
  }

  /*--------------------------------------------------------------------
    Evolution parameters
  --------------------------------------------------------------------*/

  // Copy parameter list
  void cpyparw(double *w, double *array, int n, int iset)
  {
    fcpyparw(w,array,&n,&iset);
  }

  // Get parameter key
  void keyparw(double *w, int iset)
  {
    fkeyparw(w,&iset);
  }

  // Activate parameters
  void useparw(double *w, int iset)
  {
    fuseparw(w,&iset);
  }

  /*
    Transformations
  */

  // Transform from q, qbar to e^\pm
  void efromqq(double *qvec, double *evec, int nf)
  {
    fefromqq(qvec,evec,&nf);
  }

  // Transform from e^\pm to q, qbar 
  void qqfrome(double *evec, double *qvec, int nf)
  {
    fqqfrome(evec,qvec,&nf);
  }

  /*--------------------------------------------------------------------
    Convolution
  --------------------------------------------------------------------*/

  //  Convolution x[f \otimes K]
  double fcrossk(double *w, int idw, int idum, int idf, int ix, int iq)
  {
    return ffcrossk(w,&idw,&idum,&idf,&ix,&iq);
  }

  //  Convolution x[f_a \otimes f_b]
  double fcrossf(double *w, int idw, int idum, int ida, int idb, int ix, int iq)
  {
    return ffcrossf(w,&idw,&idum,&ida,&idb,&ix,&iq);
  }

  // Interpolation
  void stfunxq(double (*stfun)(int*,int*), double *x, double *qmu2, double *stf, int n, int ichk)
  {
    fstfunxq(stfun,x,qmu2,stf,&n,&ichk);
  }

  /*--------------------------------------------------------------------
    Fast convolution
  --------------------------------------------------------------------*/

  // Pass a list of x and mu2
  void fastini(double *x, double *qmu2, int n, int ichk)
  {
    ffastini(x,qmu2,&n,&ichk);
  }

  // Clear buffer
  void fastclr(int ibuf)
  {
    ffastclr(&ibuf);
  }

  // Store a PDF in a buffer
  void fastinp(double *w, int idf, double *coef, int ibuf, int iadd)
  {
    ffastinp(w,&idf,coef,&ibuf,&iadd);
  }

  // Store |g,e^\pm> in a buffer
  void fastepm(int idum, int idf, int ibuf)
  {
    ffastepm(&idum,&idf,&ibuf);
  }

  // Store singlet or non-singlet
  void fastsns(int iset, double *def, int isel, int ibuf)
  {
    ffastsns(&iset,def,&isel,&ibuf);
  }

  // Store weighted sum of |e^\pm>
  void fastsum(int iset, double *coef, int ibuf)
  {
    ffastsum(&iset,coef,&ibuf);
  }

  //  Convolution x[f \otimes K]
  void fastfxk(double *w, int *idw, int ibuf1, int ibuf2)
  {
    ffastfxk(w,idw,&ibuf1,&ibuf2);
  }

  //  Convolution x[f_a \otimes f_b]
  void fastfxf(double *w, int *idw, int ibuf1, int ibuf2, int ibuf3)
  {
    ffastfxf(w,idw,&ibuf1,&ibuf2,&ibuf3);
  }

  // Scale by a kinematic factor
  void fastkin(int ibuf, double (*fun)(int*,int*,int*,int*))
  {
    ffastkin(&ibuf,fun);
  }

  // Copy or accumulate result
  void fastcpy(int ibuf1, int ibuf2, int iadd)
  {
    ffastcpy(&ibuf1,&ibuf2,&iadd);
  }

  // Interpolate final result
  void fastfxq(int ibuf, double *f, int n)
  {
    ffastfxq(&ibuf,f,&n);
  }

}
