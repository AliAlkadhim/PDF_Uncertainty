// C++ definition

#include "QCDNUM/QCDNUM.h"
//#include "QCDNUM/CHARACTER.h"
#include "QCDNUM/QCDNUMfw.h"

#include <sstream>
#include <cstring>
#include <string>
#include <iostream>
using namespace std;

#define STR_EXPAND(top) #top
#define STR(tok) STR_EXPAND(tok)

namespace QCDNUM {

  /*
    ==========================================
    Subroutine and function calls in ZMSTF
    (corresponding to Table 5 of the write-up)
    ==========================================
  */

  // Words available, used
  void zmwords(int &ntotal, int &nused)
  {
    fzmwords(&ntotal,&nused);
  }

  // Fill weight tables
  void zmfillw(int &nused)
  {
    fzmfillw(&nused);
  }

  // Dump weight tables
  void zmdumpw(int lun, string fname)
  {
    int ls = fname.size();
    char *cfname = new char[ls];
    strcpy(cfname,fname.c_str());
    fzmdumpwcpp(&lun,cfname,&ls);
  }
  
  // Read weight tables
  void zmreadw(int lun, string fname, int &nused, int &ierr)
  {
    int ls = fname.size();
    char *cfname = new char[ls];
    strcpy(cfname,fname.c_str());
    fzmreadwcpp(&lun,cfname,&ls,&nused,&ierr);
  }

  // Define Q2
  void zmdefq2(double a, double b)
  {
    fzmdefq2(&a,&b);
  }

  // Retrieve a and b coefficients
  void zmabval(double &a, double &b)
  {
    fzmabval(&a,&b);
  }

  // Convert muF2 to Q2
  double zmqfrmu(double qmu2)
  {
    return fzmqfrmu(&qmu2);
  }

  // Convert Q2 to muF2
  double zmufrmq(double Q2)
  {
    return fzmufrmq(&Q2);
  }

  // Switch PDF set
  void zswitch(int iset)
  {
    fzswitch(&iset);
  }

  // Structure functions
  void zmstfun(int istf, double *def, double *x, double *Q2, double *f, int n, int ichk)
  {
    fzmstfun(&istf,def,x,Q2,f,&n,&ichk);
  }

}
