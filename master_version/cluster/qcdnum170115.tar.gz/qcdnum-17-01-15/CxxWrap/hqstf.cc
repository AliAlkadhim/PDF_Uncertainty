// C++ definition

#include "QCDNUM/QCDNUM.h"
//#include "QCDNUM/CHARACTER.h"
#include "QCDNUM/QCDNUMfw.h"

#include <sstream>
#include <cstring>
#include <string>
#include <iostream>
using namespace std;

#define STR_EXPAND(top) #top
#define STR(tok) STR_EXPAND(tok)

namespace QCDNUM {

  /*
    ==========================================
    Subroutine and function calls in HQSTF
    (corresponding to Table 6 of the write-up)
    ==========================================
  */

  // Words available, used
  void hqwords(int &ntotal, int &nused)
  {
    fhqwords(&ntotal,&nused);
  }

  // Fill weight tables
  void hqfillw(int istf, double *qmass, double aq, double bq, int &nused)
  {
    fhqfillw(&istf,qmass,&aq,&bq,&nused);
  }

  // Dump weight tables
  void hqdumpw(int lun, string fname)
  {
    int ls = fname.size();
    char *cfname = new char[ls];
    strcpy(cfname,fname.c_str());
    fhqdumpwcpp(&lun,cfname,&ls);
  }
  
  // Read weight tables
  void hqreadw(int lun, string fname, int &nused, int &ierr)
  {
    int ls = fname.size();
    char *cfname = new char[ls];
    strcpy(cfname,fname.c_str());
    fhqreadwcpp(&lun,cfname,&ls,&nused,&ierr);
  }

  // Retrieve parameters
  void hqparms(double *qmass, double &a, double &b)
  {
    fhqparms(qmass,&a,&b);
  }

  // Convert muF2 to Q2
  double hqqfrmu(double qmu2)
  {
    return fhqqfrmu(&qmu2);
  }

  // Convert Q2 to muF2
  double hqmufrq(double Q2)
  {
    return fhqmufrq(&Q2);
  }

  // Switch PDF set
  void hswitch(int iset)
  {
    fhswitch(&iset);
  }

  // Structure functions
  void hqstfun(int istf, int icbt, double *def, double *x, double *Q2, double *f, int n, int ichk)
  {
    fhqstfun(&istf,&icbt,def,x,Q2,f,&n,&ichk);
  }

}
