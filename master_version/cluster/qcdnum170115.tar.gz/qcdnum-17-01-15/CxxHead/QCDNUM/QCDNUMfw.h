#ifndef QCDNUMfw_H
#define QCDNUMfw_H

// Declarations for the Fortran/C interface
#include "QCDNUM/FortranWrappers.h"

extern "C" {

  // QCDNUM

#define fqcinitcpp FC_FUNC(qcinitcpp,QCINITCPP)
  void fqcinitcpp(int*, char*, int*);

#define fsetluncpp FC_FUNC(setluncpp,SETLUNCPP)
  void fsetluncpp(int*, char*, int*);

#define fnxtlun FC_FUNC(nxtlun,NXTLUN)
  int fnxtlun(int*);

#define fsetvalcpp FC_FUNC(setvalcpp,SETVALCPP)
  void fsetvalcpp(char*, int*, double*);

#define fgetvalcpp FC_FUNC(getvalcpp,GETVALCPP)
  void fgetvalcpp(char*, int*, double*);

#define fsetintcpp FC_FUNC(setintcpp,SETINTCPP)
  void fsetintcpp(char*, int*, int*);

#define fgetintcpp FC_FUNC(getintcpp,GETINTCPP)
  void fgetintcpp(char*, int*, int*);

#define fqstorecpp FC_FUNC(qstorecpp,QSTORECPP)
  void fqstorecpp(char*, int*, int*, double*);
    
#define fgxmake FC_FUNC(gxmake,GXMAKE)
  void fgxmake(double*, int*, int*, int*, int*, int*);

#define fixfrmx FC_FUNC(ixfrmx,IXFRMX)
  int fixfrmx(double*);

#define fxfrmix FC_FUNC(xfrmix,XFRMIX)
  double fxfrmix(int*);

#define fxxatix FC_FUNC(xxatix,XXATIX)
  int fxxatix(double*, int*);

#define fgqmake FC_FUNC(gqmake,GQMAKE)
  void fgqmake(double*, double*, int*, int*, int*);

#define fiqfrmq FC_FUNC(iqfrmq,IQFRMQ)
  int fiqfrmq(double*);

#define fqfrmiq FC_FUNC(qfrmiq,QFRMIQ)
  double fqfrmiq(int*);

#define fqqatiq FC_FUNC(qqatiq,QQATIQ)
  int fqqatiq(double*, int*);

#define fgrpars FC_FUNC(grpars,GRPARS)
  void fgrpars(int*, double*, double*, int*, double*, double*, int*);

#define fgxcopy FC_FUNC(gxcopy,GXCOPY)
  void fgxcopy(double*, int*, int*);

#define fgqcopy FC_FUNC(gqcopy,GQCOPY)
  void fgqcopy(double*, int*, int*);

#define ffillwt FC_FUNC(fillwt,FILLWT)
  void ffillwt(int*, int*, int*, int*);

#define fdmpwgtcpp FC_FUNC(dmpwgtcpp,DMPWGTCPP)
  void fdmpwgtcpp(int*, int*, char*, int*);

#define freadwtcpp FC_FUNC(readwtcpp,READWTCPP)
  void freadwtcpp(int*, char*, int*, int*, int*, int*, int*);
    
#define fwtfilecpp FC_FUNC(wtfilecpp,WTFILECPP)
  void fwtfilecpp(int*, char*, int*);

#define fnwused FC_FUNC(nwused,NWUSED)
  void fnwused(int*, int*, int*);

#define fsetord FC_FUNC(setord,SETORD)
  void fsetord(int*);

#define fgetord FC_FUNC(getord,GETORD)
  void fgetord(int*);

#define fsetalf FC_FUNC(setalf,SETALF)
  void fsetalf(double*, double*);

#define fgetalf FC_FUNC(getalf,GETALF)
  void fgetalf(double*, double*);

#define fsetcbt FC_FUNC(setcbt,SETCBT)
  void fsetcbt(int*, int*, int*, int*);

#define fmixfns FC_FUNC(mixfns,MIXFNS)
  void fmixfns(int*, double*, double*, double*);

#define fgetcbt FC_FUNC(getcbt,GETCBT)
  void fgetcbt(int*, double*, double*, double*);

#define fnflavs FC_FUNC(nflavs,NFLAVS)
  int fnflavs(int*, int*);
    
#define fnfrmiq FC_FUNC(nfrmiq,NFRMIQ)
  int fnfrmiq(int*, int*, int*);

#define fsetabr FC_FUNC(setabr,SETABR)
  void fsetabr(double*, double*);

#define fgetabr FC_FUNC(getabr,GETABR)
  void fgetabr(double*, double*);

#define frfromf FC_FUNC(rfromf,RFROMF)
  double frfromf(double*);

#define fffromr FC_FUNC(ffromr,FFROMR)
  double fffromr(double*);

#define fsetcut FC_FUNC(setcut,SETCUT)
  void fsetcut(double*, double*, double*, double*);

#define fgetcut FC_FUNC(getcut,GETCUT)
  void fgetcut(double*, double*, double*, double*);
    
#define fsetlim FC_FUNC(setlim,SETLIM)
  void fsetlim(int*, int*, int*, double*);
    
#define fgetlim FC_FUNC(getlim,GETLIM)
  void fgetlim(int*, double*, double*, double*, double*);
    
#define fcpypar FC_FUNC(cpypar,CPYPAR)
  void fcpypar(double*, int*, int*);

#define fkeypar FC_FUNC(keypar,KEYPAR)
  int fkeypar(int*);
    
#define fkeygrp FC_FUNC(keygrp,KEYGRP)
  int fkeygrp(int*, int*);

#define fusepar FC_FUNC(usepar,USEPAR)
  void fusepar(int*);

#define fpushcp FC_FUNC(pushcp,PUSHCP)
  void fpushcp();

#define fpullcp FC_FUNC(pullcp,PULLCP)
  void fpullcp();

#define fasfunc FC_FUNC(asfunc,ASFUNC)
  double fasfunc(double*, int*, int*);

#define faltabn FC_FUNC(altabn,ALTABN)
  double faltabn(int*, int*, int*, int*);

#define fevolfg FC_FUNC(evolfg,EVOLFG)
  void fevolfg(int*, double (*)(int* ,double*), double*, int*, double*);
    
#define fevsgns FC_FUNC(evsgns,EVSGNS)
  void fevsgns(int*, double (*)(int* ,double*), int*, int*, int*, double*);

#define fpdfcpy FC_FUNC(pdfcpy,PDFCPY)
  void fpdfcpy(int*, int*);

#define fextpdf FC_FUNC(extpdf,EXTPDF)
  void fextpdf(double (*)(int*, double* ,double* ,bool*), int*, int*, double*, double*);
    
#define fusrpdf FC_FUNC(usrpdf,USRPDF)
  void fusrpdf(double (*)(int*, double* ,double* ,bool*), int*, int*, double*, double*);

#define fnptabs FC_FUNC(nptabs,NPTABS)
  int fnptabs(int*);
    
#define fievtyp FC_FUNC(ievtyp,IEVTYP)
  int fievtyp(int*);

#define fbvalxq FC_FUNC(bvalxq,BVALXQ)
  double fbvalxq(int*, int*, double*, double*, int*);

#define fbvalij FC_FUNC(bvalij,BVALIJ)
  double fbvalij(int*, int*, int*, int*, int*);

#define ffvalxq FC_FUNC(fvalxq,FVALXQ)
  double ffvalxq(int*, int*, double*, double*, int*);

#define ffvalij FC_FUNC(fvalij,FVALIJ)
  double ffvalij(int*, int*, int*, int*, int*);

#define fallfxq FC_FUNC(allfxq,ALLFXQ)
  void fallfxq(int*, double*, double*, double*, int*, int*);

#define fallfij FC_FUNC(allfij,ALLFIJ)
  void fallfij(int*, int*, int*, double*, int*, int*);

#define fsumfxq FC_FUNC(sumfxq,SUMFXQ)
  double fsumfxq(int*, double*, int*, double*, double*, int*);

#define fsumfij FC_FUNC(sumfij,SUMFIJ)
  double fsumfij(int*, double*, int*, int*, int*, int*);

#define ffflist FC_FUNC(fflist,FFLIST)
  void ffflist(int*, double*, int*, double*, double*, double*, int*, int*);

#define fftable FC_FUNC(ftable,FTABLE)
  void fftable(int*, double*, int*, double*, int*, double*, int*, double*, int*);
    
#define fffplotcpp FC_FUNC(ffplotcpp,FFPLOTCPP)
  void fffplotcpp(char*, int*, double (*)(int*, double*, bool*), int*, double*,  double*, int*, char*, int*);
    
#define fsplchk FC_FUNC(splchk,SPLCHK)
  double fsplchk(int*, int*, int*);

#define ffsplne FC_FUNC(fsplne,FSPLNE)
  double ffsplne(int*, int*, double*, int*);

#define fqcardscpp FC_FUNC(qcardscpp,QCARDSCPP)
  void fqcardscpp(void (*)(string*, int* ,string*, int* ,string*, int* ,int* ), char*, int*, int*);

#define fqcbookcpp FC_FUNC(qcbookcpp,QCBOOKCPP)
  void fqcbookcpp(char*, int*, char*, int*);

  // ZMSTF

#define fzmwords FC_FUNC(zmwords,ZMWORDS)
  void fzmwords(int*, int*);

#define fzmfillw FC_FUNC(zmfillw,ZMFILLW)
  void fzmfillw(int*);

#define fzmdumpwcpp FC_FUNC(zmdumpwcpp,ZMDUMPWCPP)
  void fzmdumpwcpp(int*, char*, int*);

#define fzmreadwcpp FC_FUNC(zmreadwcpp,ZMREADWCPP)
  void fzmreadwcpp(int*, char*, int*, int*, int*);

#define fzmdefq2 FC_FUNC(zmdefq2,ZMDEFQ2)
  void fzmdefq2(double*, double*);

#define fzmabval FC_FUNC(zmabval,ZMABVAL)
  void fzmabval(double*, double*);

#define fzmqfrmu FC_FUNC(zmqfrmu,ZMQFRMU)
  double fzmqfrmu(double*);

#define fzmufrmq FC_FUNC(zmufrmq,ZMUFRMQ)
  double fzmufrmq(double*);

#define fzswitch FC_FUNC(zswitch,ZSWITCH)
  void fzswitch(int*);

#define fzmstfun FC_FUNC(zmstfun,ZMSTFUN)
  void fzmstfun(int*, double*, double*, double*, double*, int*, int*);

#define fhqwords FC_FUNC(hqwords,HQWORDS)
  void fhqwords(int*, int*);

#define fhqfillw FC_FUNC(hqfillw,HQFILLW)
  void fhqfillw(int*, double*, double*, double*, int*);

#define fhqdumpwcpp FC_FUNC(hqdumpwcpp,HQDUMPWCPP)
  void fhqdumpwcpp(int*, char*, int*);

#define fhqreadwcpp FC_FUNC(hqreadwcpp,HQREADWCPP)
  void fhqreadwcpp(int*, char*, int*, int*, int*);

#define fhqparms FC_FUNC(hqparms,HQPARMS)
  void fhqparms(double*, double*, double*);

#define fhqqfrmu FC_FUNC(hqqfrmu,HQQFRMU)
  double fhqqfrmu(double*);

#define fhqmufrq FC_FUNC(hqmufrq,HQMUFRQ)
  double fhqmufrq(double*);

#define fhswitch FC_FUNC(hswitch,HSWITCH)
  void fhswitch(int*);

#define fhqstfun FC_FUNC(hqstfun,HQSTFUN)
  void fhqstfun(int*, int*, double*, double*, double*, double*, int*, int*);

#define fmaketab FC_FUNC(maketab,MAKETAB)
  void fmaketab(double*, int*, int*, int*, int*, int*, int*);

#define fsetparw FC_FUNC(setparw,SETPARW)
  void fsetparw(double*, int*, double *, int*);

#define fgetparw FC_FUNC(getparw,GETPARW)
  void fgetparw(double*, int*, double *, int*);

#define fdumptabcpp FC_FUNC(dumptabcpp,DUMPTABCPP)
  void fdumptabcpp(double*, int*, int*, char*, int*, char*, int*);

#define freadtabcpp FC_FUNC(readtabcpp,READTABCPP)
  void freadtabcpp(double*, int*, int*, char*, int*, char*, int*, int*, int*, int*, int*);

#define fidspfuncpp FC_FUNC(idspfuncpp,IDSPFUNCPP)
  int fidspfuncpp(char*, int*, int*, int*);

#define fipdftab FC_FUNC(ipdftab,IPDFTAB)
  int fipdftab(int*, int*);

#define fmakewta FC_FUNC(makewta,MAKEWTA)
  void fmakewta(double*, int*, double (*)(double*, double*, int*), double (*)(double*));

#define fmakewtb FC_FUNC(makewtb,MAKEWTB)
  void fmakewtb(double*, int*, double (*)(double*, double*, int*), double (*)(double*), int*);

#define fmakewrs FC_FUNC(makewrs,MAKEWRS)
  void fmakewrs(double*, int*, double (*)(double*, double*, int*), double (*)(double*, double*, int*), double (*)(double*), int*);

#define fmakewtd FC_FUNC(makewtd,MAKEWTD)
  void fmakewtd(double*, int*, double (*)(double*, double*, int*), double (*)(double*));

#define fmakewtx FC_FUNC(makewtx,MAKEWTX)
  void fmakewtx(double*, int*);

#define fscalewt FC_FUNC(scalewt,SCALEWT)
  void fscalewt(double*, double*, int*);

#define fcopywgt FC_FUNC(copywgt,COPYWGT)
  void fcopywgt(double*, int*, int*, int*);

#define fwcrossw FC_FUNC(wcrossw,WCROSSW)
  void fwcrossw(double*, int*, int*, int*, int*);

#define fwtimesf FC_FUNC(wtimesf,WTIMESF)
  void fwtimesf(double*, double (*)(int*, int*), int*, int*, int*);

#define fevfilla FC_FUNC(evfilla,EVFILLA)
  void fevfilla(double*, int*, double (*)(int*,int*,int*));

#define fevgetaa FC_FUNC(evgetaa,EVGETAA)
  double fevgetaa(double*, int*, int*, int*, int*);

#define fevdglap FC_FUNC(evdglap,EVDGLAP)
  void fevdglap(double*, int***, int***, int*, double**, int*, int*, int*, int*, double*);

#define fevpdfij FC_FUNC(evpdfij,EVPDFIJ)
  double fevpdfij(double*, int*, int*, int*, int*);

#define fevplist FC_FUNC(evplist,EVPLIST)
  void fevplist(double*, int*, double*, double*, double*, int*, int*);

#define fevtable FC_FUNC(evtable,EVTABLE)
  void fevtable(double*, int*, double*, int*, double*, int*, double**, int*);

#define fevpcopy FC_FUNC(evpcopy,EVPCOPY)
  void fevpcopy(double*, int*, double**, int*, int*);

#define fcpyparw FC_FUNC(cpyparw,CPYPARW)
  void fcpyparw(double*, double*, int*, int*);

#define fkeyparw FC_FUNC(keyparw,KEYPARW)
  void fkeyparw(double*, int*);

#define fuseparw FC_FUNC(useparw,USEPARW)
  void fuseparw(double*, int*);

#define fefromqq FC_FUNC(efromqq,EFROMQQ)
  void fefromqq(double*, double*, int*);

#define fqqfrome FC_FUNC(qqfrome,QQFROME)
  void fqqfrome(double*, double*, int*);

#define ffcrossk FC_FUNC(fcrossk,FCROSSK)
  double ffcrossk(double*, int*, int*, int*, int*, int*);

#define ffcrossf FC_FUNC(fcrossf,FCROSSF)
  double ffcrossf(double*, int*, int*, int*, int*, int*, int*);

#define fstfunxq FC_FUNC(stfunxq,STFUNXQ)
  void fstfunxq(double (*)(int*, int*), double*, double*, double*, int*, int*);

#define ffastini FC_FUNC(fastini,FASTINI)
  void ffastini(double*, double*, int*, int*);

#define ffastclr FC_FUNC(fastclr,FASTCLR)
  void ffastclr(int*);

#define ffastinp FC_FUNC(fastinp,FASTINP)
  void ffastinp(double*, int*, double*, int*, int*);

#define ffastepm FC_FUNC(fastepm,FASTEPM)
  void ffastepm(int*, int*, int*);

#define ffastsns FC_FUNC(fastsns,FASTSNS)
  void ffastsns(int*, double*, int*, int*);

#define ffastsum FC_FUNC(fastsum,FASTSUM)
  void ffastsum(int*, double*, int*);

#define ffastfxk FC_FUNC(fastfxk,FASTFXK)
  void ffastfxk(double*, int*, int*, int*);

#define ffastfxf FC_FUNC(fastfxf,FASTFXF)
  void ffastfxf(double*, int*, int*, int*, int*);

#define ffastkin FC_FUNC(fastkin,FASTKIN)
  void ffastkin(int*, double (*)(int*, int*, int*, int*));

#define ffastcpy FC_FUNC(fastcpy,FASTCPY)
  void ffastcpy(int*, int*, int*);

#define ffastfxq FC_FUNC(fastfxq,FASTFXQ)
  void ffastfxq(int*, double *, int*);

}

#endif
