#ifndef QCDNUM_H
#define QCDNUM_H

#include <string>
#include <iostream>
using namespace std;

// Namespace containing all the QCDNUM wrapper functions.
namespace QCDNUM {

  /*
    ==========================================
    Subroutine and function calls in QCDNUM
    (corresponding to Table 2 of the write-up)
    ==========================================
  */

  /*
    Initialisation
  */

  // Initialise
  void qcinit(int lun, string fname);

  // Redirect output 
  void setlun(int lun, string fname);

  // Get next free lun
  int nxtlun(int lmin);

  // Set parameters
  void setval(string opt, double val);

  // Get parameters
  void getval(string opt, double &val);
  
  // Set integer parameters
  void setint(string opt, int ival);

  // Get integer parameters
  void getint(string opt, int &ival);
    
  // Set|get qstore
  void qstore(string opt, int ival, double &val);

  /*
    Grid
  */

  // Define x grid
  void gxmake(double *xmin, int *iwt, int n, int nxin, int &nxout, int iord);

  // Get ix from x
  int ixfrmx(double x);

  // Get x from ix
  double xfrmix(int ix);

  // Verify grid point
  int xxatix(double x, int ix);

  // Define muF2 grid
  void gqmake(double *qarr, double *wgt, int n, int nqin, int &nqout);

  // Get imu from muF2
  int iqfrmq(double q2);

  // Get muF2 from imu
  double qfrmiq(int iq);

  // Verify grid point
  int qqatiq(double q2, int iq);

  // Get grid definition
  void grpars(int &nx, double &xmi, double &xma, int &nq, double &qmi, double &qma, int &iord);

  // Copy x grid
  void gxcopy(double *array, int n, int &nx);

  // Copy muF2 grid
  void gqcopy(double *array, int n, int &nq);

  /*
    Weights
  */

  // Fill weight tables
  void fillwt(int itype, int &idmin, int &idmax, int &nwds);

  // Dump weight tables
  void dmpwgt(int itype, int lun, string fname);

  // Read weight tables
  void readwt(int lun, string fname, int &idmin, int &idmax, int &nwds, int &ierr);
    
  // Weight file
  void wtfile(int itype, string fname);

  // Memory words used
  void nwused(int &nwtot, int &nwuse, int &ndummy);

  /*
    Parameters
   */

  // Set order
  void setord(int iord);

  // Get order
  void getord(int &iord);

  // Set alphas start value
  void setalf(double as0, double r20);

  // Get alphas start value
  void getalf(double &as0, double &r20);

  // Set nf or thresholds
  void setcbt(int nfix, int iqc, int iqb, int iqt);

  // Set mfns parameters
  void mixfns(int nfix, double r2c, double r2b, double r2t);

  // Get nf or thresholds
  void getcbt(int &nfix, double &q2c, double &q2b, double &q2t);

  // Get nf at imu
  int nflavs(int iq, int &ithresh);
    
  // Get nf at imu
  int nfrmiq(int iset, int iq, int &ithresh);

  // Set muF2 scale
  void setabr(double ar, double br);

  // Get muF2 scale
  void getabr(double &ar, double &br);

  // Convert muF2 to muR2
  double rfromf(double fscale2);

  // Convert muR2 to muF2
  double ffromr(double rscale2);

  // Set cuts ------ OBSOLETE
  void setcut(double xmi, double q2mi, double q2ma, double dummy);

  // Get cuts ------ OBSOLETE
  void getcut(double &xmi, double &q2mi, double &q2ma, double &dummy);
    
  // Set cuts
  void setlim( int ixmin, int iqmin, int iqmax, double dummy);
    
  // Get cuts
  void getlim( int iset, double &xmin, double &qmin, double &qmax, double &dummy);

  // Copy parameter list
  void cpypar(double *array, int n, int iset);

  // Get parameter key
  int keypar(int iset);
    
  // Get selective parameter key
  int keygrp(int iset, int igrp);

  // Activate parameters
  void usepar(int iset);

  // Push on a stack
  void pushcp();

  // Pull from a stack
  void pullcp();

  /*
    Evolution
   */

  // Evolve alphas(muR2);
  double asfunc(double r2, int &nf, int &ierr);

  // Returns a_s^n(muF2);
  double altabn(int iset, int iq, int n, int &ierr);

  // Evolve PDFs
  void evolfg(int iset, double (*func)(int*, double*), double *def, int iq0, double &epsi);
    
  // Evolve PDFs
  void evsgns(int iset, double (*func)(int*, double*), int *isns, int n, int iq0, double &epsi);

  // Copy PDF set
  void pdfcpy(int iset1, int iset2);

  // Read external PDF set
  void extpdf(double (*func)(int*, double*, double*, bool*), int iset, int n, double offset, double &epsi);
    
  // Read external user PDF set
  void usrpdf(double (*func)(int*, double*, double*, bool*), int iset, int n, double offset, double &epsi);

  // Number of PDF tables
  int nptabs(int iset);
    
  // Get evolution type
  int ievtyp(int iset);

  /*
    Interpolation
   */

  // Get one basis PDF (xQ)
  double bvalxq(int iset, int id, double x, double qmu2, int ichk);

  // Get one basis PDF (ij)
  double bvalij(int iset, int id, int ix, int iq, int ichk);

  // Get one flavour PDF (xQ)
  double fvalxq(int iset, int id, double x, double qmu2, int ichk);

  // Get one flavour PDF (ij)
  double fvalij(int iset, int id, int ix, int iq, int ichk);

  // Get all flavours PDFs (xQ)
  void allfxq(int iset, double x, double qmu2, double *pdfs, int n, int ichk);

  // Get all flavours PDFs (ij)
  void allfij(int iset, int ix, int iq, double *pdfs, int n, int ichk);

  // Linear combination (xQ)
  double sumfxq(int iset, double *c, int isel, double x, double qmu2, int ichk);

  // Linear combination (ij)
  double sumfij(int iset, double *c, int isel, int ix, int iq, int ichk);

  // Make list PDFs
  void fflist(int iset, double *c, int m, double *x, double *q, double *f, int n, int ichk);

  // Make table of PDFs
  void ftable(int iset, double *c, int m, double *x, int nx, double *q, int nq, double *table, int ichk);
    
  // Make plotfile
  void ffplot(string fnam, double(* fun)(int*, double*, bool*), int m, double zmi, double zma, int n, string txt);
    
  // Check spline
  double splchk(int iset, int id, int iq);

  // Spline interpolation
  double fsplne(int iset, int id, double x, int iq);
    
    

  /*
    Datacards
   */

  // Process datacard file (???????????????)
  void qcards(void (*userkeys)(string*,int*,string*,int*,string*,int*,int*), string fname, int iprint);

  // Manage keycard
  void qcbook(string action, string key);

  /*
    ==========================================
    Subroutine and function calls in ZMSTF
    (corresponding to Table 5 of the write-up)
    ==========================================
  */

  // Words available, used
  void zmwords(int &ntotal, int &nused);

  // Fill weight tables
  void zmfillw(int &nused);

  // Dump weight tables
  void zmdumpw(int lun, string fname);
  
  // Read weight tables
  void zmreadw(int lun, string fname, int &nused, int &ierr);

  // Define Q2
  void zmdefq2(double a, double b);

  // Retrieve a and b coefficients
  void zmabval(double &a, double &b);

  // Convert muF2 to Q2
  double zmqfrmu(double qmu2);

  // Convert Q2 to muF2
  double zmufrmq(double Q2);

  // Switch PDF set
  void zswitch(int iset);

  // Structure functions
  void zmstfun(int istf, double *def, double *x, double *Q2, double *f, int n, int ichk);

  /*
    ==========================================
    Subroutine and function calls in HQSTF
    (corresponding to Table 6 of the write-up)
    ==========================================
  */

  // Words available, used
  void hqwords(int &ntotal, int &nused);

  // Fill weight tables
  void hqfillw(int istf, double *qmass, double aq, double bq, int &nused);

  // Dump weight tables
  void hqdumpw(int lun, string fname);
  
  // Read weight tables
  void hqreadw(int lun, string fname, int &nused, int &ierr);

  // Retrieve parameters
  void hqparms(double *qmass, double &a, double &b);

  // Convert muF2 to Q2
  double hqqfrmu(double qmu2);

  // Convert Q2 to muF2
  double hqmufrq(double Q2);

  // Switch PDF set
  void hswitch(int iset);

  // Structure functions
  void hqstfun(int istf, int icbt, double *def, double *x, double *Q2, double *f, int n, int ichk);

  /*
    ==========================================
    Routines in the QCDNUM toolbox
    (corresponding to Table 4 of the write-up)
    ==========================================
  */

  /*
    Workspace
  */

  // Create tables
  void maketab(double *w, int nw, int *itypes, int np, int neww, int &iset, int &nwu);

  // Store user information
  void setparw(double *w, int iset, double *upars, int n);

  // Read user information
  void getparw(double *w, int iset, double *upars, int n);

  // Dump to disk
  void dumptab(double *w, int iset, int lun, string fname, string key);

  // Read from disk
  void readtab(double *w, int nw, int lun, string fname, string key, int neww, int &iset, int &nwu, int &ierr);

  /*
    Identiers
  */

  // Internal weight table
  int idspfun(string pij, int iord, int iset);

  // Internal PDF table
  int ipdftab(int iset, int id);

  /*
    Weights
  */

  // Regular piece A(x)
  void makewta(double *w, int id, double (*afun)(double*,double*,int*), double (*achi)(double*));

  // Singular piece [B(x)]_+
  void makewtb(double *w, int id, double (*bfun)(double*,double*,int*), double (*achi)(double*), int nodelta);

  // Product R(x)[S(x)]_+
  void makewrs(double *w, int id, double (*rfun)(double*,double*,int*), double (*sfun)(double*,double*,int*), double (*achi)(double*), int nodelta);

  // Delta-function D(x)delta(1-x)
  void makewtd(double *w, int id, double (*dfun)(double*,double*,int*), double (*achi)(double*));

  // Weights for x[f_a \otime f_b]
  void makewtx(double *w, int id);

  /*
    Combined weights
  */

  // Scale weight table
  void scalewt(double *w, double c, int id);

  // Copy weight table
  void copywgt(double *w, int id1, int id2, int iadd);

  // Convolution of weights
  void wcrossw(double *w, int ida, int idb, int idc, int iadd);

  // Multiply by f(mu2,nf)
  void wtimesf(double *w, double (*fun)(int*,int*), int id1, int id2, int iadd);

  /*
    Evolution
  */

  // Fill table of coefficients 
  void evfilla(double *w, int id, double (*func)(int*,int*,int*));

  // Get coefficients
  double evgetaa(double *w, int id, int iq, int &nf, int &ithresh);

  // Coupled evolution
  void evdglap(double *w, int ***idw, int ***ida, int *idf, double **start, int m, int n, int *iqlim, int &nf, double &epsi);

  /*
    Access to pdfs
  */

  //  PDF at a grid point
  double evpdfij(double *w, int id, int ix, int iq, int ichk);

  // List of interpolated PDFs
  void evplist(double *w, int id, double *x, double *qmu2, double *pdf, int n, int ichk);

  // Table of interpolated PDFs
  void evtable(double *w, int id, double *x, int nx, double *q, int nq, double **table, int ichk);

  // Copy to internal memory
  void evpcopy(double *w, int id, double **def, int n, int iset);

  /*
    Evolution parameters
  */

  // Copy parameter list
  void cpyparw(double *w, double *array, int n, int iset);

  // Get parameter key
  void keyparw(double *w, int iset);

  // Activate parameters
  void useparw(double *w, int iset);

  /*
    Transformations
  */

  // Transform from q, qbar to e^\pm
  void efromqq(double *qvec, double *evec, int nf);

  // Transform from e^\pm to q, qbar 
  void qqfrome(double *evec, double *qvec, int nf);

  /*
    Convolution
  */

  //  Convolution x[f \otimes K]
  double fcrossk(double *w, int idw, int idum, int idf, int ix, int iq);

  //  Convolution x[f_a \otimes f_b]
  double fcrossf(double *w, int idw, int idum, int ida, int idb, int ix, int iq);

  // Interpolation
  void stfunxq(double (*stfun)(int*,int*), double *x, double *qmu2, double *stf, int n, int ichk);

  /*
    Fast convolution
  */

  // Pass a list of x and mu2
  void fastini(double *x, double *qmu2, int n, int ichk);

  // Clear buffer
  void fastclr(int ibuf);

  // Store a PDF in a buffer
  void fastinp(double *w, int idf, double *coef, int ibuf, int iadd);

  // Store |g,e^\pm> in a buffer
  void fastepm(int idum, int idf, int ibuf);

  // Store singlet or non-singlet
  void fastsns(int iset, double *def, int isel, int ibuf);

  // Store weighted sum of |e^\pm>
  void fastsum(int iset, double *coef, int ibuf);

  //  Convolution x[f \otimes K]
  void fastfxk(double *w, int *idw, int ibuf1, int ibuf2);

  //  Convolution x[f_a \otimes f_b]
  void fastfxf(double *w, int *idw, int ibuf1, int ibuf2, int ibuf3);

  // Scale by a kinematic factor
  void fastkin(int ibuf, double (*fun)(int*,int*,int*,int*));

  // Copy or accumulate result
  void fastcpy(int ibuf1, int ibuf2, int iadd);

  // Interpolate final result
  void fastfxq(int ibuf, double *f, int n);

}

#endif
