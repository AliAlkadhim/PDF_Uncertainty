#include "stdio.h"

#include "genetic_dummy.h"

//------------------------------------------------------------------------------
void genetic_search(Fcn fcn_in)
{

  // dummy version advertises normal version
  printf("Run dummy version of the GENETIC routine.\n To really run it re-configure the xFitter with the flag --enable-genetic.\n");

  return;

}
