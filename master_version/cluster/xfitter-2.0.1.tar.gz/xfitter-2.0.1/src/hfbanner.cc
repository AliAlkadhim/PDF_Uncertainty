#include <iostream>
#include "xfitter_cpp.h"

using namespace std;
void hfbanner_()
{
 cout << "                     FFFFFFFFFFFFFFFFFFFFFF  iiii          tttt               tttt                                                  " << endl;
 cout << "                     F::::::::::::::::::::F i::::i      ttt:::t            ttt:::t                                                  " << endl;
 cout << "                     F::::::::::::::::::::F  iiii       t:::::t            t:::::t                                                  " << endl;
 cout << "                     FF::::::FFFFFFFFF::::F             t:::::t            t:::::t                                                  " << endl;
 cout << " xxxxxxx      xxxxxxx  F:::::F       FFFFFFiiiiiiittttttt:::::tttttttttttttt:::::ttttttt        eeeeeeeeeeee    rrrrr   rrrrrrrrr   " << endl;
 cout << "  x:::::x    x:::::x   F:::::F             i:::::it:::::::::::::::::tt:::::::::::::::::t      ee::::::::::::ee  r::::rrr:::::::::r  " << endl;
 cout << "   x:::::x  x:::::x    F::::::FFFFFFFFFF    i::::it:::::::::::::::::tt:::::::::::::::::t     e::::::eeeee:::::eer:::::::::::::::::r " << endl;
 cout << "    x:::::xx:::::x     F:::::::::::::::F    i::::itttttt:::::::tttttttttttt:::::::tttttt    e::::::e     e:::::err::::::rrrrr::::::r" << endl;
 cout << "     x::::::::::x      F:::::::::::::::F    i::::i      t:::::t            t:::::t          e:::::::eeeee::::::e r:::::r     r:::::r" << endl;
 cout << "      x::::::::x       F::::::FFFFFFFFFF    i::::i      t:::::t            t:::::t          e:::::::::::::::::e  r:::::r     rrrrrrr" << endl;
 cout << "      x::::::::x       F:::::F              i::::i      t:::::t            t:::::t          e::::::eeeeeeeeeee   r:::::r            " << endl;
 cout << "     x::::::::::x      F:::::F              i::::i      t:::::t    tttttt  t:::::t    tttttte:::::::e            r:::::r            " << endl;
 cout << "    x:::::xx:::::x   FF:::::::FF           i::::::i     t::::::tttt:::::t  t::::::tttt:::::te::::::::e           r:::::r            " << endl;
 cout << "   x:::::x  x:::::x  F::::::::FF           i::::::i     tt::::::::::::::t  tt::::::::::::::t e::::::::eeeeeeee   r:::::r            " << endl;
 cout << "  x:::::x    x:::::x F::::::::FF           i::::::i       tt:::::::::::tt    tt:::::::::::tt  ee:::::::::::::e   r:::::r            " << endl;
 cout << " xxxxxxx      xxxxxxxFFFFFFFFFFF           iiiiiiii         ttttttttttt        ttttttttttt      eeeeeeeeeeeeee   rrrrrrr            " << endl;
 cout << endl;
 cout << "  Version " << VERSION << endl;
 cout << "  " << PACKAGE_URL << "                             " <<  PACKAGE_BUGREPORT << endl;
 cout << "----------------------------------------------------------------------------------------" << endl;
 cout << endl;
 cout << endl;
}
