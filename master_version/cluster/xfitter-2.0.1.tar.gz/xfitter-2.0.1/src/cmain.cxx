

extern "C" void xfitter_();

int main() {
  xfitter_();
  return 0;
}
