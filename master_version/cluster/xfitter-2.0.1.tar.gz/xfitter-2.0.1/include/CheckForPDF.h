#ifndef __CHECKFORPDF_H
#define __CHECKFORPDF_H

void CheckForPDF(char *pdfname);

#endif
