extern "C" void testplot();
extern "C" void FillwHist(double * weights,  double * chi2,int nrep_old, int method);

void testplot(){
  return;
}

void FillwHist(double * weights,  double * chi2,int ndata,double nrep_old, int method){
  return;
}
