#ifndef ParPainter_h
#define ParPainter_h
extern bool ParPainter();
#endif
