#include <vector>
#include <TCanvas.h>
#include <Dataset.h>

using namespace std;

TCanvas *DataPainter(int dataindex,  int subplotindex);
