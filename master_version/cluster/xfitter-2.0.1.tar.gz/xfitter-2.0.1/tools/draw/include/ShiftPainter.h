#include <TCanvas.h>
using namespace std;

vector <TCanvas*> ShiftPainter(vector<string> dirs);
