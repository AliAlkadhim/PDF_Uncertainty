#ifndef Chi2scanPainter_h
#define Chi2scanPainter_h
#include <TCanvas.h>

#include <vector>

using namespace std;

extern vector<TCanvas*> Chi2scanPainter();

#endif
