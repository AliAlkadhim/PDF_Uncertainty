#include <vector>
#include <string>
using namespace std;

bool FitPainter();
